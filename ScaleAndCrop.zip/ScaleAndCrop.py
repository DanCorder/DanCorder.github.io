#!/usr/bin/env python

# ==============================================================================
#                   ScaleAndCrop.py V1.0 - (c) Daniel Corder 2010
# ==============================================================================
#
# Accepts a target image print size and dpi, then scales the image to the
# required resolution and crops the sides of the image if necessary to fit.
#
# ==============================================================================
#
# This program is free software; you can redistribute it and/or modify it.
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# ==============================================================================

import math
from gimpfu import *

# TODO Work out how to remember and display last used parameters

def scaleAndCrop (
	xiImage,
	xiDrawable,
	xiWidthInches,
	xiHeightInches,
	xiDpi):

	lOriginalWidth = xiImage.width
	lOriginalHeight = xiImage.height
	lOriginalWidthHeightRatio = float(lOriginalWidth) / float(lOriginalHeight)
	
	lTargetWidth = round(xiWidthInches * xiDpi)
	lTargetHeight = round(xiHeightInches * xiDpi)
	lTargetWidthHeightRatio = float(lTargetWidth) / float(lTargetHeight)
	
	if (lOriginalWidthHeightRatio > lTargetWidthHeightRatio):
		lScaledHeight = xiHeightInches * xiDpi
		lScaledWidth = round( float(lOriginalWidth) * float(lScaledHeight) / float(lOriginalHeight) )
	else:
		lScaledWidth = xiWidthInches * xiDpi
		lScaledHeight = round( float(lOriginalHeight) * float(lScaledWidth) / float(lOriginalWidth) )

	#TODO Use gimp_image_scale_full and allow user to choose interpolation type
	pdb.gimp_image_scale(
		xiImage,
		lScaledWidth,
		lScaledHeight)
		
	#TODO zoom image to fill window
	
	#TODO Change this so that instead of cropping we display the crop tool with
	#     the correct selection
	pdb.gimp_image_crop(
		xiImage,
		lTargetWidth,
		lTargetHeight,
		round((lScaledWidth - lTargetWidth) / 2),
		round((lScaledHeight - lTargetHeight) / 2))

	return

register(
	"ScaleCrop",
	"Scale and crop and image to a specific size and dpi",
	"Scale and crop and image to a specific size and dpi",
	"Daniel Corder",
	"Daniel Corder",
	"2010",
	"<Image>/Image/Transform/Scale & Crop",
	"RGB*, GRAY*",
	[
		(PF_FLOAT, "width_inches", "width in inches", 12.0),
		(PF_FLOAT, "height_inches", "height in inches", 16.0),
		(PF_INT, "target_dpi", "dpi of final image", 402)
	],
	[],
	scaleAndCrop)

main()
